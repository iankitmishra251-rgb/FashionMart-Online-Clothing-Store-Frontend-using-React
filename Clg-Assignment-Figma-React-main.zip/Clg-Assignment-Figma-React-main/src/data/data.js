const DATA = [
    {
        id : 1,
        image : "https://imgs.search.brave.com/WdK-hux7BMH7ibaYg2vzhz_VIA4ZjJcOXIsewYJWBNM/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9jZG4u/ZGlzcGxhdGUuY29t/L2FydHdvcmsvMjcw/eDM4MC8yMDIyLTAz/LTA0LzdmMmJlMzE1/OTEyMDJjMzJmMTY5/ODkwODRiZDA5ZDIw/XzU2MjU2MTcwNjVm/MmVkZTA4ZGRhODQw/NjdkNjI2MjdhLmpw/Zw",
        title : "The Squid Games",
        subtitle : "Netflix",
        link : "https://www.netflix.com/in/title/81040344"
    },
    {
        id : 2,
        image : "https://m.media-amazon.com/images/S/pv-target-images/d5bfa39778c26ef991811b23d2402f18ce0a1b91a61702578cea3bcdc4314681._BR-6_AC_SX720_FMwebp_.jpg",
        title : "Panchayat",
        subtitle : "Amazon Prime",
        link : "https://www.primevideo.com/detail/Panchayat/0KAFPP1MAADAFUOA6I2WR5D4TM"
    },
    {
        id : 3,
        image : "https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRhqFk8nITteea0sobPZkX2gKuZOxYd0m4wwnJk-AdPQX39fiO90-UesKhYtriNWihHtfg1",
        title : "Mirzapur",
        subtitle : "Amazon Prime",
        link : "https://www.primevideo.com/detail/Mirzapur/0PDOKMV9CRLOMO5EUKNCUJLG4Q"
    },
    {
        id : 4,
        image : "https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcTZuoUSwTMdgYjIZglurAETKajn9xf-y4GJAv-mwktLXysJtMDxRxCG7_xwi6xAmhAnEUie",
        title : "Kota Factory",
        subtitle : "Netflix",
        link : "https://www.netflix.com/in/title/81249783"
    },

    {
        id : 5,
        image : "https://imgs.search.brave.com/eUqy25mUTy6cGdQPJ0whxyc7xyFs7TiExcCMTgQyElM/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly93MC5w/ZWFrcHguY29tL3dh/bGxwYXBlci8xODIv/NjA1L0hELXdhbGxw/YXBlci10aGUtc29j/aWV0eS10di1zZXJp/ZXMtbmV0ZmxpeC1u/ZXRmbGl4LXR2LXNl/cmllcy10aHVtYm5h/aWwuanBn",
        title : "The Society",
        subtitle : "Netflix",
        link : "https://www.netflix.com/in/title/81249783"
    },
    
];

export default DATA;